import React, { Component } from 'react';

import './App.css';
import * as firebase from 'firebase';
import { firebaseConnect } from './firebaseConnect.js';
import Nav from'./Nav.js'
import Container from './Container.js'
import {connect} from 'react-redux' 
class App extends Component {
  constructor(props){
    super(props);
    this.state={
      node: ''
    }
    this.getData = this.getData.bind(this)
  }
  // connectFB = () =>{
  //   var data = firebase.database().ref('dataForNote')
  //   data.push({
  //     id:4,
  //     title:'ngày 5/10/2018',
  //     note: ' đã thêm được dữ liệu vào db'
  //   })
  // }
  // xoadulieu = (id) =>{
  //   var data = firebase.database().ref('dataForNote')
  // data.child(id).remove()
  // console.log('đã xóa được id là: ' + id)
  // }
  getData(data){
   console.log('getdata da lay duoc gia tri la:' +data.note)
    //  var dataConnect = firebase.database().ref('dataForNote')
    //  dataConnect.push(data)
}  


  render() {
           
          console.log(firebaseConnect)
    return (
      <div className="App">
        <Nav/>
        <Container getdata={(data)=>{this.getData(data)}}/>




          {/* <button onClick={()=>this.connectFB()}>ADD NEW VALUE</button>
          <button onClick={()=>this.xoadulieu('-LQ9JYVH7ta7KIn20fng')}>DELETE VALUE</button> */}
     
      </div>
    );
  }
}


export default connect()(App)