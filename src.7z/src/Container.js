import React, { Component } from 'react';
import {connect} from 'react-redux' 

class Container extends Component {
    constructor(props){
        super(props)
        this.state={
            userNote:{
            title: '',
            note: ''},
            listtest: [123,21312,312,3,12,3]
        }
        this.handleChange = this.handleChange.bind(this)
        this.handleSubmitForm = this.handleSubmitForm.bind(this)
    }
    handleChange(event){
        this.setState({
            userNote : Object.assign({},this.state.userNote,{
                [event.target.name] : event.target.value
            })
          
        })
    }
    handleSubmitForm(event){
        const note = {
            note: this.state.userNote.note,
            title: this.state.userNote.title
        }

        event.preventDefault()
        this.setState({
            userNote:{
                title: '',
                note: ''}
        })
        console.log(note)
       this.props.handleAdd(note)
      }
    render() {
      console.log(JSON.stringify(this.props.list))
        console.log(typeof(this.props.list))
        return (
        
            <div>
                   
                    <div className="container">
      <div className="row">
     
              <div className="col">

                <div id="accordianId" role="tablist" aria-multiselectable="true">
                    <div className="card">
                        <div className="card-header" role="tab" id="section1HeaderId">
                            <h5 className="mb-0">
                                <a data-toggle="collapse" data-parent="#accordianId" href="#section1ContentId" aria-expanded="true" aria-controls="section1ContentId">
                          Ngay 31/10/2018 
                        </a>
                            </h5>
                        </div>
                        <div id="section1ContentId" className="collapse in" role="tabpanel" aria-labelledby="section1HeaderId">
                            <div className="card-body">
                               Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum exercitationem est, deleniti alias velit iure officiis ipsam repudiandae in iste id possimus voluptates earum ducimus? Assumenda accusamus atque rem a.
                            </div>
                        </div>
                    </div>

                </div>

                <div id="accordianId" role="tablist" aria-multiselectable="true">
                        <div className="card">
                            <div className="card-header" role="tab" id="section1HeaderId">
                                <h5 className="mb-0">
                                    <a data-toggle="collapse" data-parent="#accordianId" href="#section2ContentId" aria-expanded="true" aria-controls="section2ContentId">
                              Ngay 1/11/2018 
                            </a>
                                </h5>
                            </div>
                            <div id="section2ContentId" className="collapse in" role="tabpanel" aria-labelledby="section1HeaderId">
                                <div className="card-body">
                                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum exercitationem est, deleniti alias velit iure officiis ipsam repudiandae in iste id possimus voluptates earum ducimus? Assumenda accusamus atque rem a.
                                </div>
                            </div>
                        </div>
    
                    </div>


              </div>
              
                <div className="col-4">
                   {/* <form onSubmit={this.handleSubmitForm}>
                      Title: {''}<input type="text" name="title" id="title" className="form-control" placeholder="" aria-describedby="helpId" value={this.state.userNote.title} onChange={this.handleChange}/>
                      Note: {''} <input type="text" name="note" id="note" className="form-control" placeholder="" aria-describedby="helpId" value={this.state.userNote.note} onChange={this.handleChange}/>

                    <button className="btn btn-primary" onClick={(data)=>{
                        this.props.getdata(this.state.userNote)}}>submit</button>
                   </form> */}

                   
                  
                </div>
            
                <form onSubmit={this.handleSubmitForm}>
                    Title: {''}<input type="text" name="title" id="title" className="form-control" placeholder="" aria-describedby="helpId" value={this.state.userNote.title} onChange={this.handleChange}/>
                    Note: {''} <input type="text" name="note" id="note" className="form-control" placeholder="" aria-describedby="helpId" value={this.state.userNote.note} onChange={this.handleChange}/>
                    {/* //   Title: {''}<input type="text" name="title" id="title" className="form-control" placeholder="" aria-describedby="helpId" value={this.props.Note.title} onChange={(event)=>{event.preventDefault()
                    // this.props.handleChange(event.target.name, event.target.value)}}/>
                    //   Note: {''} <input type="text" name="note" id="note" className="form-control" placeholder="" aria-describedby="helpId" value={this.props.Note.note} onChange={(event)=>{event.preventDefault()
                    // this.props.handleChange(event.target.name, event.target.value)}}/> */}

                    <button className="btn btn-primary" >submit</button>
                   </form>
              
                </div>    
               
      </div>
  
    </div>

  
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        Note: state.userNote,
        ten: state.vinh,
        net : state.nested,
        list : state.noteList
    }
}


const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        handleAdd: (getdata) => {
            dispatch({
                type: 'ADD_STATE',
                getdata
            })
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Container)