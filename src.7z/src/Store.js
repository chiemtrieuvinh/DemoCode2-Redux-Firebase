import * as firebase from 'firebase';
var redux = require('redux')



const titleInitialState = {
    userNote:{
    title: 'qwe',
    note: 'qweqwe'
    },
    vinh: 'vinhchiem',
    nested:{
        name:'qweqwe'
    },
    noteList :[]
}
const title = (state = titleInitialState, action) => {
    switch(action.type)
    {
        case 'ADD_STATE':
            console.log('ket noi thanh cong' + JSON.stringify(action.getdata))
            var data = firebase.database().ref('dataForNote')
            data.push(action.getdata)
            return {...state, userNote : action.getdata, noteList: [].concat(state.noteList,action.getdata)}
        case 'CHANGE_USER':
            return Object.assign({},state,{
                userNote: Object.assign({},state.userNote,{
                    [action.name] : action.value
                })
            })
        default:
            return state
    }
}

var store1 = redux.createStore(title)

export default store1